import { Component } from '@angular/core';
@Component({
    selector: 'as-edit-category',
    template: require('./category-edit.component.html')
})
export class CategoryEdit {

    public tableData = [];
    public Category = '';
    public oldText = '';
    public oldSubcategory = '';
    addCategory() {
        for (let i = 0; i < this.tableData.length; i++) {
            this.tableData[i].showSubcategory = true;
        }
        let obj = {
            'editable': true,
            'value': this.Category,
            'subCategory': [],
            'showSubcategory': false
        };
        this.tableData.push(obj);
        this.Category = '';
    }
    addSubCategory(row, id) {
        for (let i = 0; i < this.tableData.length; i++) {
            if (this.tableData[i].showSubcategory === false) {
                let eleId: string = 'addSubcategory';
                let inputValue = (<HTMLInputElement>document.getElementById(eleId)).value;
                console.log(id);
                let obj = {
                    'editable': true,
                    'value': inputValue
                };
                this.tableData[i].subCategory.push(obj);
                (<HTMLInputElement>document.getElementById(eleId)).value = '';
                this.tableData[i].showSubcategory = false;
                break;
            }
        }

    }
    deleteCategory(row) {
        console.log(row);
        let index = (this.tableData.indexOf(row));
        this.tableData.splice(index, 1);
    }
    deleteSubCategory(row: any, indexCat: any) {
        console.log(row);
        let index = (this.tableData[indexCat].subCategory.indexOf(row));
        if (index > -1) {
            this.tableData[index].subCategory.splice(index, 1);
        }
    }

    enableSubCategory(row) {
        for (let i = 0; i < this.tableData.length; i++) {
            this.tableData[i].showSubcategory = true;
        }
        console.log(row);
        row.showSubcategory = false;
    }

    beginEdit(el: HTMLElement, index: string): void {
        console.log(el);
        this.oldText = this.tableData[index].value;
        this.tableData[index].editable = false;
    }
    beginsubCategoryEdit(el: HTMLElement, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(el));
        if (index > -1) {
            this.oldSubcategory = this.tableData[indexCat].subCategory[index].value;
            this.tableData[indexCat].subCategory[index].editable = false;
            console.log(this.tableData[indexCat].subCategory[index].editable);
        }
    }
    editDone(newText, index: string): void {
        console.log('edit done');
        newText.editable = true;
    }
    editsubCategoryDone(newText, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(newText));
        if (index > -1) {
            this.tableData[indexCat].subCategory[index].editable = true;
            this.tableData[indexCat].showSubcategory = false;
            console.log(this.tableData[indexCat].subCategory[index].editable);
        }
    }
    editCancel(newText, index: string): void {
        console.log('edit cancel');
        newText.value = this.oldText;
        newText.editable = true;
        this.oldText = '';
    }
    editsubCategoryCancel(newText, indexCat: string): void {
        let index = (this.tableData[indexCat].subCategory.indexOf(newText));
        if (index > -1) {
            this.tableData[indexCat].subCategory[index].editable = true;
            this.tableData[indexCat].showSubcategory = false;
            this.tableData[indexCat].subCategory[index].value = this.oldSubcategory;
        }
    }
    onRowClick(event, id) {
        console.log(event.target.outerText, id);
    }
}
